<!DOCTYPE html>
<html lang="en">
<head>
</br>
</br>
</br>
</br>
</br>

<div id="service">
	<div class="container">
 			<div class="row centered">
				<div class="col-lg-8 col-lg-offset-2">
					<p class="lead">
						<span class="label label-warning">High Data Transfer</span>
						<span class="label label-primary">High Speed Connection</span>
						<span class="label label-success">Hide Your IP</span>
						<span class="label label-info">Best VPN Server</span>
						<span class="label label-info">Premium SSH Server</span>
						<span class="label label-warning">Worldwide Servers</span>
						<span class="label label-primary">Secure Shell</span>
						<span class="label label-success">Exclusive</span><br/>
						<span class="label label-danger">No DDOS</span>
						<span class="label label-danger">No Hacking</span>
						<span class="label label-danger">No Carding</span>
						<span class="label label-danger">No Spamm</span>
						<span class="label label-danger">No Torrent</span>
						<span class="label label-danger">No Fraud</span>
						<span class="label label-danger">No Repost</span>
				</div>				
</div></div></div><!-- end of service, container, row centered -->	
<center><iframe src="https://coinmedia.co/new_code_site49846.js" scrolling="no" frameborder="0" width="728px" height="120px"></iframe></center>
<div id="login-overlay" class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h4 class="modal-title" id="myModalLabel"><center>YOUR STATUS DESKTOP<center></h4>
          </div>
          <div class="modal-body">
		  <div class="narrow text-center">
<a href="https://www.wieistmeineip.de/cometo/?en"><img src="https://www.wieistmeineip.de/ip-address/?size=468x60" border="0" width="468" height="60" alt="IP" /></a>
 		  <div class="alert alert-success " style="display: none;"></div>
          </div>
  <div class="narrow text-center"> 
			</div></div></div></div>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="http://www.iconj.com/ico/l/z/lzo5pwpfhi.ico" type="image/x-icon" />

    <title>YOUR STATUS</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <script src='https://www.google.com/recaptcha/api.js'></script>    <!-- <script src="assets/js/modernizr.js"></script> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/ajaxRequest.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/retina-1.1.0.js"></script>
    <script src="assets/js/jquery.hoverdir.js"></script>
    <script src="assets/js/jquery.hoverex.min.js"></script>
    <script src="assets/js/jquery.prettyPhoto.js"></script>
    <script src="assets/js/jquery.isotope.min.js"></script>
     <script src="assets/js/custom.js"></script>
  </style>
  </head>

<body>
<div class="navbar navbar-default navbar-fixed-top" role="navigation"><div class="container">
     <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="http://overses.net">VOZOV CREATOR SSH</a>
	</div>
     <div class="navbar-collapse collapse navbar-right">
          <ul class="nav navbar-nav">
		    <li><a href="http://overses.net"><i class="fa fa-home"></i> Awal</a></li>
			<li><a href="contact"><i class="fa fa-location-arrow"></i> Hubungi Kami</a></li>
			<li><a href="status.php"><i class="fa fa-cog"></i> Status</a></li>
			</ul>
</div></div></div></div>
  <div class="narrow text-center"> 
			</div></div></div>
 		  <div class="alert alert-success " style="display: none;"></div>
          </div>
  <div class="narrow text-center"> 
			</div></div></div>  
 </br></br></br>
<div id="footer" class="container-fluid row8">
	<div class="container">
		<div class="row">
    	 	<div class="col-md-6 col-sm-6 col-xs-12 footer-left">
        		© Copyright Website 2017 <strong><a href="http://overses.net">SSHINJECTOR.NET</a></strong>.
        	</div>
    	</div>
	</div>
</div>


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/ajaxRequest.js"></script>
	<script src="assets/js/retina-1.1.0.js"></script>
	<script src="assets/js/jquery.hoverdir.js"></script>
	<script src="assets/js/jquery.hoverex.min.js"></script>
	<script src="assets/js/jquery.prettyPhoto.js"></script>
  	<script src="assets/js/jquery.isotope.min.js"></script>
  	<script src="assets/js/custom.js"></script>
	
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/58e8ba7f30ab263079b5f052/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</script>
</body>
</html>