<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="http://www.iconj.com/ico/l/z/lzo5pwpfhi.ico" type="image/x-icon" />

    <title>VOZOV Creator SSH Free</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <script src='https://www.google.com/recaptcha/api.js'></script>    <!-- <script src="assets/js/modernizr.js"></script> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/ajaxRequest.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/retina-1.1.0.js"></script>
    <script src="assets/js/jquery.hoverdir.js"></script>
    <script src="assets/js/jquery.hoverex.min.js"></script>
    <script src="assets/js/jquery.prettyPhoto.js"></script>
    <script src="assets/js/jquery.isotope.min.js"></script>
     <script src="assets/js/custom.js"></script>
    <style>
  body{background:#fffff;font-family:arial;}
  #wrapshopcart{width:350px;margin:3em auto;padding:30px;background:#fff;box-shadow:0 0 5px #c1c1c1;border-radius: 5px;}
  h1{margin:0;padding:0;font-size:2.5em;font-weight:bold;}
  p{font-size:1em;margin:0;}
  table{margin:2em 0 0 0; border:1px solid #eee;width:100%; border-collapse: separate;border-spacing:0;}
  table th{background:#fafafa; border:none; padding:20px ; font-weight:normal;text-align:left;}
  table td{background: #fff;border: none;padding: 10px 5px;font-weight: normal;text-align: left;}
  table tr.total td{font-size:1.5em;}
  .btnsubmit{display:inline-block;padding:10px;border:1px solid #ddd;background:#eee;color:#000;text-decoration:none;margin:2em 0;}
  form{margin:2em 0 0 0;}
  label{display:inline-block;width:12em;}
  select{background: #ffffff;padding: 5px;}
  input[type=text]{border:1px solid #bbb;padding:10px;width:100%;border-radius: 5px;background: #ffffff;}
  textarea{border:1px solid #bbb;padding:10px;width:100%;height:5em;vertical-align:text-top;margin:0.3em 0 0 0;border-radius: 5px;}
  .submitbtn{font-size:15px;display:inline-block;padding:10px;border:1px solid #ddd;background:#0091ce;color:#fff;text-decoration:none;margin:0.8em 0 0 0em;border-radius: 5px;};
   
  </style>
  </head>

<body>
<div class="navbar navbar-default navbar-fixed-top" role="navigation"><div class="container">
     <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="http://overses.net">VOZOV CREATOR SSH</a>
	</div>
     <div class="navbar-collapse collapse navbar-right">
          <ul class="nav navbar-nav">
		    <li><a href="http://overses.net"><i class="fa fa-home"></i> Awal</a></li>
			<li><a href="contact"><i class="fa fa-location-arrow"></i> Hubungi Kami</a></li>
			<li><a href="status.php"><i class="fa fa-cog"></i> Status</a></li>
			</ul>
    </div>
</div></div>
</br></br></br></br>

             <center><font size="30"><b>VOZOV Creator SSH Free</br></font><br></center>


<div id="service">
	<div class="container">
 			<div class="row centered">
				<div class="col-lg-8 col-lg-offset-2">
					<p class="lead">
						<span class="label label-warning">High Data Transfer</span>
						<span class="label label-primary">High Speed Connection</span>
						<span class="label label-success">Hide Your IP</span>
						<span class="label label-info">Best VPN Server</span>
						<span class="label label-info">Premium SSH Server</span>
						<span class="label label-warning">Worldwide Servers</span>
						<span class="label label-primary">Secure Shell</span>
						<span class="label label-success">Exclusive</span><br/>
						<span class="label label-danger">No DDOS</span>
						<span class="label label-danger">No Hacking</span>
						<span class="label label-danger">No Carding</span>
						<span class="label label-danger">No Spamm</span>
						<span class="label label-danger">No Torrent</span>
						<span class="label label-danger">No Fraud</span>
						<span class="label label-danger">No Repost</span>
				</div>				
</div></div></div><!-- end of service, container, row centered -->	
 <div class="container">
     <div class="panel panel-default">	
         <div class="panel-body">
		<center><font size="6"><b>YOUR STATUS</br></font><br></center>
		 					<hr color ='Grey' width='100%'/>
 <center><script src="//api.find-ip.net/widget.js?width=240&region=0&city=0&language=0&system=0&"></script></center>	
</script>
</center>
            
  </div>
      </div>
 </br>
<div id="login-overlay" class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h4 class="modal-title" id="myModalLabel"><center>VOZOV Creator SSH Free</center></h4>
          </div>
          <div class="modal-body">
		  <div class="narrow text-center">
<form>
<div class="form-group">
    <label for="username">Username:</label>
    <input type="text" class="form-control" name="username">
  </div>
  <div class="form-group">
    <label for="password">Password:</label>
    <input type="password" class="form-control" name="password">
  </div>
  <div class="form-group">
  	<p hidden><select class="form-control" name="server"></p>
    		<option value="Masukan IP VPS Anda Disini !!!">

  	</select>
  </div>
 <div class="form-group">
<div class="g-recaptcha" data-sitekey="6LcJtCgUAAAAANvawl_dztl9TLbN7to59zTZvOdV"></div>

  <div class="form-group"><div id="response"></div></div>
  <button type="submit" class="btn btn-info btn-sm btn-group btn-group-justified" id="submit">Create Acccount SSH</button>
  <br/><br/>
 		  <div class="alert alert-success " style="display: none;"></div>
          </div>
  <div class="narrow text-center"> 
			</div></div></div>
</form>
</div>
</div></div></div>
<div id="footerwrap">
<div class="container">
		<h4><font size="3" color="#384452">Kembali ke halaman <a color="White"href="http://overses.net/">Awal</a></h4>
		 			<h4><font size="2" color="#384452">Copyright © 2017 <a href="#">OVERSES.NET</a> Create SSH Premium For Free</a></h4>
	<div class="pull-right">
            <br />
		 			<h4><font size="5"><a href="#"><b>CONTACT US</b></a></h4>
                <a href="#"><i class="fa fa-facebook-square fa-3x social"></i></a>
	        <a href="#"><i class="fa fa-twitter-square fa-3x social"></i></a>
             <a href="#"><i class="fa fa-instagram" style="font-size:30px"></i></a>
	            <a href="https://www.facebook.com/jordhia"><i class="fa fa-envelope-square fa-3x social"></i></a>
					</div>
	</div>
</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/ajaxRequest.js"></script>
	<script src="assets/js/retina-1.1.0.js"></script>
	<script src="assets/js/jquery.hoverdir.js"></script>
	<script src="assets/js/jquery.hoverex.min.js"></script>
	<script src="assets/js/jquery.prettyPhoto.js"></script>
  	<script src="assets/js/jquery.isotope.min.js"></script>
  	<script src="assets/js/custom.js"></script>
</body>
</html>